#!/usr/bin/env python
# coding: utf-8

# # For https://archive.ics.uci.edu/ml/machine-learning-databases/00222/  --> bank-additional.zip
# # The classification goal is to predict if the client will subscribe (yes/no) a term deposit (variable y).
# 

# ### The data consists of 41,188 instances and 20 attributes
# ### I have taken a reduced set of 6 attributes
# ### and converted Categoricals to Numericals along the way

# In[1]:


import numpy as np 
import pandas as pd
from sklearn.tree import DecisionTreeClassifier


# In[2]:


#converted the ";" delimited file to "," delimited file first before reading the file
file="C:\Trainings\My_DataScience_Python_Projects\Bank_Marketing\\bank-additional-full.csv"


# In[3]:


df_full=pd.read_csv(file)


# In[4]:


df_reduced=df_full[['age','job','marital','education','housing','loan','y']]


# In[5]:


#get X as the attributes (Feature Matrix)
X=df_full[['age','job','marital','education','housing','loan']].values

#get Y as the dependent variable
y=df_full[['y']]


# In[6]:


#convert categoricals to numerics


# In[7]:


from sklearn import preprocessing

le_job = preprocessing.LabelEncoder()
le_job.fit(['admin.','blue-collar','entrepreneur','housemaid','management','retired','self-employed','services','student','technician','unemployed','unknown'])

le_marital = preprocessing.LabelEncoder()
le_marital.fit(['divorced','married','single','unknown'])

le_education = preprocessing.LabelEncoder()
le_education.fit(['illiterate','basic.4y','basic.6y','basic.9y','high.school','university.degree','professional.course','unknown'])

le_housing = preprocessing.LabelEncoder()
le_housing.fit(['no','yes','unknown'])

le_loan = preprocessing.LabelEncoder()
le_loan.fit(['no','yes','unknown'])

X[:,1] = le_job.transform(X[:,1])
X[:,2] = le_marital.transform(X[:,2])
X[:,3] = le_education.transform(X[:,3])
X[:,4] = le_housing.transform(X[:,4])
X[:,5] = le_loan.transform(X[:,5])


# In[8]:


#setup the decision tree
from sklearn.model_selection import train_test_split

#Use 70% for Training and 30% for Testing

X_trainset, X_testset, y_trainset, y_testset = train_test_split(X, y, test_size=0.3, random_state=3)


# In[9]:


#create the decision tree model
TermDepositTree = DecisionTreeClassifier(criterion="entropy", max_depth = 4)


# In[10]:


#Fit the data with the Training Feature Matrix and Traning Response Matrix
TermDepositTree.fit(X_trainset,y_trainset)


# In[11]:


#Prediction Tree
predTree = TermDepositTree.predict(X_testset)


# In[12]:


#compare the values for 5 rows
print (predTree [0:5])
print (y_testset [0:5])


# In[13]:


#Evaluate to check the accuracy of the model
from sklearn import metrics
import matplotlib.pyplot as plt
print("DecisionTrees's Accuracy: ", metrics.accuracy_score(y_testset, predTree))


# ### The Accuracy of the Model is 0.8871
